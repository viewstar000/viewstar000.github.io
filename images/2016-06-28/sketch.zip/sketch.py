#!/usr/bin/env python
#coding:utf8
import os
import sys
import shutil
import hashlib
import os.path
import xml.etree.ElementTree as ET

from zipfile import ZipFile


def _U(text):

    if not isinstance(text, unicode):
        return str(text).decode('UTF8')
    else:
        return text

def _S(text):

    if isinstance(text, unicode):
        return text.encode('UTF8')
    else:
        return str(text)


TAG_PREFIX = '{urn:xmind:xmap:xmlns:content:2.0}'

def _TAG(name, **kwargs):

    tag = ''
    if name in ('', '.', '..', '*') or name.startswith(TAG_PREFIX):
        tag = name
    else:
        tag = TAG_PREFIX + name
    if kwargs:
        attrbute    = ','.join(("@%s='%s'" % item for item in kwargs.iteritems()))
        tag         = tag + '[' + attrbute +']'
    return tag


def _PATH(*args):

    return '/'.join(map(_TAG, args))


class TopicNode(object):

    @classmethod
    def get_by_id(cls, root, id):

        ele = root.find(_PATH('.', '', _TAG('topic', id = id)))
        if ele is not None:
            return cls(ele, root)
        else:
            return None

    def __init__(self, ele, root = None):

        self.root   = root
        self.ele    = ele

    def __str__(self):

        res = self.title + '-' + self.id
        if isinstance(res, unicode):
            return res.encode('utf8')
        else:
            return res

    @property
    def id(self):

        return self.ele.get('id', None)
    
    @property
    def title(self):

        return self.ele.find(_PATH('title')).text

    @property
    def weight(self):

        for marker_ref in self.ele.iterfind(_PATH('marker-refs','marker-ref')):
            marker_id = marker_ref.get('marker-id', 'priority-1')
            if marker_id.startswith('priority-'):
                return int(marker_id[9:])
        return 1

    @property
    def height(self):
        
        for marker_ref in self.ele.iterfind(_PATH('marker-refs','marker-ref')):
            marker_id = marker_ref.get('marker-id', '')
            if marker_id == 'symbol-plus':
                return 2
            elif marker_id == 'c_simbol-plus':
                return 4
            elif marker_id == 'symbol-minus':
                return 0.5
            elif marker_id == 'c_simbol-minus':
                return 0.25
        return 1
    
    @property
    def progress(self):

        for marker_ref in self.ele.iterfind(_PATH('marker-refs','marker-ref')):
            marker_id = marker_ref.get('marker-id', '')
            if marker_id.startswith('task-'):
                return marker_id[5:]
        return None

    @property
    def folded(self):

        return self.ele.get('branch', '') == 'folded'

    @property
    def notes(self):

        plain = self.ele.find(_PATH('notes','plain'))
        if plain is not None:
            return plain.text
        else:
            return ''

    @property
    def markers(self):
        
        markers = []
        for marker_ref in self.ele.iterfind(_PATH('marker-refs','marker-ref')):
            marker_id = marker_ref.get('marker-id', '')
            if marker_id:
                markers.append(marker_id)
        return markers
    
    @property
    def children(self):

        for topic in self.ele.iterfind(_PATH('children',_TAG('topics', type='attached'),'topic')):
            yield TopicNode(topic, self.root)

    @property
    def base_on(self):
        
        for relationship in self.root.iterfind(_PATH('sheet', 'relationships', _TAG('relationship', end1=self.id))):
            title_ele   = relationship.find(_PATH('title'))
            title       = title_ele is not None and title_ele.text or ''
            if title.upper() == '' or title.upper() == 'BASEON' or title.upper() == 'BASE_ON' or title.upper() == 'BASE ON':
                return self.get_by_id(self.root, relationship.get('end2'))

    @property
    def based_by(self):

        for relationship in self.root.iterfind(_PATH('sheet', 'relationships', _TAG('relationship', end2=self.id))):
            title_ele   = relationship.find(_PATH('title'))
            title       = title_ele is not None and title_ele.text or ''
            if title.upper() == '' or title.upper() == 'BASEON' or title.upper() == 'BASE_ON' or title.upper() == 'BASE ON':
                yield self.get_by_id(self.root, relationship.get('end1'))
    
    @property
    def uses(self):
        
        for topic in self.ele.iterfind(_PATH('children',_TAG('topics', type='summary'),'topic')):
            title_ele   = topic.find(_PATH('title'))
            title       = title_ele is not None and title_ele.text or ''
            if title and not title.startswith('_'):
                yield TopicNode(topic, self.root)
    


class SketchObject(list):

    UNIT_WIDTH      = 40
    UNIT_HEIGHT     = 60
    PADDING_WIDTH   = 10
    PADDING_HEIGHT  = 10
    SPACE_WIDTH     = 10
    SPACE_HEIGHT    = 10
    LABEL_HEIGHT    = 20
    CONTAIN_ROWS    = 1

    @staticmethod
    def FromTopicNode(node, max_level = None, level = 0):

        so = SketchObject(node.id, node.title, node.weight, node.height, 
            progress    = node.progress, 
            notes       = '\n'.join(node.notes), 
            markers     = node.markers
        )
        if max_level and max_level <= level:
            return so
        if node.folded:
            return so
        for base_node in filter(lambda n:n.base_on == None, node.children):
            top_nodes = list(base_node.based_by)
            if top_nodes:
                so.append(SketchGroup.FromTopicNode(base_node, top_nodes, max_level, level + 1))
            else:
                so.append(SketchObject.FromTopicNode(base_node, max_level, level + 1))
        for use_node in node.uses:
            so.uses.append(SketchObject.FromTopicNode(use_node, max_level, level + 1))
        return so

    def __init__(self, id = None, title = None, weight = 1, v_weight = 1, *items, **attributes):

        super(SketchObject, self).__init__(items)
        self.id         = id
        self.title      = title
        self.weight     = int(weight)
        self.v_weight   = v_weight
        self.attributes = attributes
        self.uses       = []
        self.row        = 0
        self.col        = 0
        self.row_span   = 1
        self.col_span   = 1
        self.left       = 0
        self.top        = 0
        self.width      = 0
        self.height     = 0

    def __str__(self):

        return _S("{%s: %s -> %s}" % (_S(self.title), ', '.join(map(_S, self)), ', '.join(map(_S, self.uses))))

    def update_children_position(self):

        child_row   = 0
        child_col   = 0
        child_left  = self.PADDING_WIDTH
        child_top   = self.PADDING_HEIGHT + self.LABEL_HEIGHT
        for so in self:
            so.row      = child_row
            so.col      = child_col
            so.left     = child_left
            so.top      = child_top
            child_col  += so.col_span
            child_left += so.width + self.SPACE_WIDTH

        child_left += self.PADDING_WIDTH
        child_top   = self.PADDING_HEIGHT
        for so in self.uses:
            so.row      = child_row
            so.col      = child_col
            so.left     = child_left
            so.top      = child_top
            child_col  += so.col_span
            child_left += so.width + self.SPACE_WIDTH

    def update_layout(self, width, height):

        no_space_self_width     = self.width - self.PADDING_WIDTH * 2 - self.SPACE_WIDTH * (len(self) + len(self.uses) - 1)
        no_space_new_width      = width - self.PADDING_WIDTH * 2 - self.SPACE_WIDTH * (len(self) + len(self.uses) - 1)

        if len(self.uses):
            no_space_self_width -= self.SPACE_WIDTH
            no_space_new_width  -= self.SPACE_WIDTH

        no_space_self_height    = self.height - self.LABEL_HEIGHT - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)
        no_space_new_height     = height - self.LABEL_HEIGHT - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)

        no_space_use_height     = self.height - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)
        no_space_new_use_height = height - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)

        #print 'Update Layout:', self.width, self.height, no_space_self_width, no_space_self_height, no_space_use_height, '->', width, height, no_space_new_width, no_space_new_height, no_space_new_use_height

        for so in self:
            so.update_layout(no_space_new_width * so.width / no_space_self_width, no_space_new_height * so.height / no_space_self_height)

        for so in self.uses:
            so.update_layout(no_space_new_width * so.width / no_space_self_width, no_space_new_use_height * so.height / no_space_use_height)

        self.width  = width
        self.height = height
        self.update_children_position()
        
    def compute_layout(self):

        children = self + self.uses
        if not len(children):
            self.row_span   = 1
            self.col_span   = self.weight
            self.width      = int(self.weight * self.UNIT_WIDTH)
            self.height     = int(self.v_weight * self.UNIT_HEIGHT)
        else:
            map(lambda so: so.compute_layout(), children)
            self.col_span   = sum(map(lambda so:so.col_span, children))
            self.row_span   = max(map(lambda so:so.row_span, children))
            self.width      = sum(map(lambda so:so.width, children)) + self.SPACE_WIDTH*(len(children) - 1) + self.PADDING_WIDTH*2
            self.height     = max(map(lambda so:so.height, children)) + self.PADDING_HEIGHT*2 + self.LABEL_HEIGHT
            if len(self.uses):
                self.width += self.SPACE_WIDTH
            map(lambda so: so.update_layout(so.width, self.height - self.PADDING_HEIGHT*2 - self.LABEL_HEIGHT), self)
            map(lambda so: so.update_layout(so.width, self.height - self.PADDING_HEIGHT*2), self.uses)
            self.update_children_position()

    def output_html(self, fout, ext_class = '', level = 0):

        if len(self) + len(self.uses) == 0:
            ext_class += ' leaf'

        progress = self.attributes.get('progress', '')
        if progress:
            ext_class += ' progress progress-' + progress
        
        markers = ' '.join(self.attributes.get('markers', []))
        if markers:
            ext_class += ' ' + markers

        print >> fout, ' ' * level * 4, '<div id="%s" class="%s %s" data-col="%s" data-row="%s" data-col-span="%s" data-row-span="%s" style="position:absolute;left:%spx;top:%spx;width:%spx;height:%spx">' % (
            self.id, type(self).__name__, ext_class, 
            self.col, self.row, self.col_span, self.row_span, 
            self.left, self.top, self.width, self.height,
        ) 
        print >> fout, ' ' * (level+1) * 4, _S('<span class="title">%s</span>' %  self.title)
        for ss in self:
            ss.output_html(fout, 'contain', level + 1)
        for ss in self.uses:
            ss.output_html(fout, 'use', level + 1)
        print >> fout, ' ' * level * 4, '</div>'

    def output_graffle(self, fout, offset_x = 0, offset_y = 0, ext_class = 'contain'):

        for ss in self:
            ss.output_graffle(fout, offset_x + self.left, offset_y + self.top, 'contain')
        for ss in self.uses:
            ss.output_graffle(fout, offset_x + self.left, offset_y + self.top, 'use')
        if isinstance(self, SketchGroup):
            pass
        else:
            if ext_class == 'use':
                print >> fout, ('        make new shape at end of graphics with properties' + \
                    ' {shadow fuzziness: 3, size: {%s, %s}, origin: {%s, %s}, shadow color: {0, 0, 0, 0.2}, shadow beneath: true,' + \
                    ' text: {size: 16, font: "HelveticaNeue", text: "%s"}, text placement: top, fill color: {0.000000, 0.749020, 0.752941}}') % (
                        self.width, self.height, offset_x + self.left, offset_y + self.top, _S(self.title)
                    ) 
            else:
                print >> fout, ('        make new shape at end of graphics with properties' + \
                    ' {shadow fuzziness: 3, size: {%s, %s}, origin: {%s, %s}, shadow color: {0, 0, 0, 0.2}, shadow beneath: true,' + \
                    ' text: {size: 16, font: "HelveticaNeue", text: "%s"}, text placement: top}') % (
                        self.width, self.height, offset_x + self.left, offset_y + self.top, _S(self.title)
                    ) 



class SketchGroup(SketchObject):

    PADDING_WIDTH   = 0
    PADDING_HEIGHT  = 0
    LABEL_HEIGHT    = 0
    CONTAIN_ROWS    = 2

    @staticmethod
    def FromTopicNode(base_node, nodes, max_level = None, level = 0):
    
        sg = SketchGroup(SketchObject.FromTopicNode(base_node, max_level, level))
        for node in nodes:
            top_nodes = list(node.based_by)
            if top_nodes:
                sg.append(SketchGroup.FromTopicNode(node, top_nodes, max_level, level))
            else:
                sg.append(SketchObject.FromTopicNode(node, max_level, level))
        return sg

    def __init__(self, *items, **attributes):

        super(SketchGroup, self).__init__(0, '', 1, 1, *items, **attributes)    

    def update_children_position(self):

        top_col_span    = sum(map(lambda so:so.col_span, self[1:]))
        top_row_span    = max(map(lambda so:so.row_span, self[1:]))
        top_width       = sum(map(lambda so:so.width, self[1:])) + self.SPACE_WIDTH*(len(self) - 2)
        top_height      = max(map(lambda so:so.height, self[1:]))

        self[0].row     = top_row_span
        self[0].col     = 0
        self[0].left    = self.PADDING_WIDTH
        self[0].top     = self.PADDING_HEIGHT + top_height + self.SPACE_HEIGHT + self.LABEL_HEIGHT

        top_row         = 0
        top_col         = 0
        top_left        = self.PADDING_WIDTH
        top_top         = self.PADDING_HEIGHT + self.LABEL_HEIGHT
        for so in self[1:]:
            so.row      = top_row
            so.col      = top_col
            so.left     = top_left
            so.top      = top_top
            top_col    += so.col_span
            top_left   += so.width + self.SPACE_WIDTH

    def update_layout(self, width, height):

        no_space_self_width     = self.width - self.PADDING_WIDTH * 2 - self.SPACE_WIDTH * (len(self) - 2)
        no_space_new_width      = width - self.PADDING_WIDTH * 2 - self.SPACE_WIDTH * (len(self) - 2)

        no_space_self_height    = self.height - self.LABEL_HEIGHT - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)
        no_space_new_height     = height - self.LABEL_HEIGHT - self.PADDING_HEIGHT * 2 - self.SPACE_HEIGHT * (self.CONTAIN_ROWS - 1)

        self[0].update_layout(width - self.PADDING_WIDTH * 2, no_space_new_height * self[0].height / no_space_self_height)

        map(lambda so: so.update_layout(no_space_new_width * so.width / no_space_self_width, no_space_new_height * so.height / no_space_self_height), self[1:])

        self.width  = width
        self.height = height
        self.update_children_position()

    def compute_layout(self):

        if not len(self):
            self.row_span   = 1
            self.col_span   = self.weight
            self.width      = int(self.weight * self.UNIT_WIDTH)
            self.height     = int(self.v_weight * self.UNIT_HEIGHT)
        else:
            map(lambda so:so.compute_layout(), self)
            base_col_span   = self[0].col_span
            base_row_span   = self[0].row_span
            base_width      = self[0].width
            base_height     = self[0].height
            top_col_span    = sum(map(lambda so:so.col_span, self[1:]))
            top_row_span    = max(map(lambda so:so.row_span, self[1:]))
            top_width       = sum(map(lambda so:so.width, self[1:])) + self.SPACE_WIDTH*(len(self) - 2)
            top_height      = max(map(lambda so:so.height, self[1:]))
            self.col_span   = max(base_col_span, top_col_span)
            self.row_span   = (base_row_span + top_row_span)
            self.width      = max(base_width, top_width) + self.PADDING_WIDTH*2
            self.height     = (base_height + top_height) + self.SPACE_HEIGHT + self.PADDING_HEIGHT*2 + self.LABEL_HEIGHT
            self[0].update_layout(self.width - self.PADDING_WIDTH*2, self[0].height)
            if top_width < self.width:
                no_space_width      = self.width - self.PADDING_WIDTH*2 - self.SPACE_WIDTH*(len(self) - 2)
                no_space_top_width  = top_width - self.SPACE_WIDTH*(len(self) - 2)
                map(lambda so: so.update_layout(no_space_width * so.width / no_space_top_width, top_height), self[1:])
            else:
                map(lambda so: so.update_layout(so.width, top_height), self[1:])
            self.update_children_position()




def print_tree(element, level = 0):

    print ' ' * level * 4, element, element.base_on, '|'.join(map(str, element.uses))
    for child in element.children:
        print_tree(child, level + 1)


def print_sketch(sketch, level = 0, prefix = ''):

    print ' ' * level * 4, prefix, type(sketch).__name__, sketch.title, sketch.col_span, sketch.row_span, sketch.width, sketch.height
    for ss in sketch:
        print_sketch(ss, level + 1, 'CONTAIN')
    for ss in sketch.uses:
        print_sketch(ss, level + 1, 'USE')


def open_xmind(fn):

    xmind_file      = ZipFile(fn)
    content_file    = xmind_file.open('content.xml')
    content_root    = ET.parse(content_file)
    return content_root


def output_html(sketch, output_path, name = 'output'):

    name = _S(name)
    with open(os.path.join(output_path, name + '.html'), 'w') as fout:
        fout.write("""<html>
<head>
<meta charset="UTF-8">
<title>%s</title>
<link rel="stylesheet" href="sketch.css">
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="sketch.js"></script>
<script language="javascript">
var name = "%s";
</script>
</head>
<body>
""" % (name, name))
        sketch.output_html(fout)
        fout.write("</body></html>")

    shutil.copyfile(os.path.join(os.path.dirname(__file__), 'jquery.js'), os.path.join(output_path, 'jquery.js'))
    shutil.copyfile(os.path.join(os.path.dirname(__file__), 'sketch.js'), os.path.join(output_path, 'sketch.js'))
    shutil.copyfile(os.path.join(os.path.dirname(__file__), 'sketch.css'), os.path.join(output_path, 'sketch.css'))
    output_hash = hashlib.md5(open(os.path.join(output_path, name + '.html'), 'rb').read()).hexdigest()
    open(os.path.join(output_path, name + '.hash'), 'w').write(output_hash)

    print output_hash


def output_graffle(sketch, output_path, name = 'output'):

    name = _S(name)
    with open(os.path.join(output_path, name + '.scpt'), 'w') as fout:
        fout.write("""\
tell application id "com.omnigroup.OmniGraffle6"
    tell canvas of front window
""")
        sketch.output_graffle(fout)
        fout.write("""\
    end tell
end tell
""")

    os.system('osascript ' + os.path.join(output_path,'output.scpt'))


if __name__ == '__main__':

    if len(sys.argv) >= 3:
        output_format   = sys.argv[1].strip('-')
        input_name      = sys.argv[2]
    else:
        output_format   = 'html'
        input_name      = sys.argv[1]

    output_path, ext    = os.path.splitext(input_name)
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    content_root    = open_xmind(input_name)
    content_root.write(os.path.join(output_path, 'content.xml'), encoding='UTF8')

    for topic_root  in content_root.iterfind(_PATH('sheet','topic')):

        sketch_root = TopicNode(topic_root, content_root)
        sketch      = SketchObject.FromTopicNode(sketch_root, 0)
        sketch.compute_layout()

        print 'Output', sketch.title
        if output_format == 'html':
            output_html(sketch, output_path, sketch.title)
        elif output_format == 'graffle':
            output_graffle(sketch, output_path, sketch.title)
            break;
        else:
            print 'Unkown Output Format:', output_format


# '/Users/lili01/Library/Application Scripts/com.omnigroup.OmniGraffle6/draw_arch.scpt'
# '/Users/lili01/OneDrive/Desktop/_H2规划/架构全景.xmind'