
function watchHash() {
    $.get(name + '.hash?_s='+Math.random(), function (data) {
        data = data.trim();
        if (data != window.location.hash.slice(1)){
            window.location.hash = data;
            window.location.reload();
        }
        setTimeout(watchHash, 1000);
    }, 'text');
}

$(document).ready(function () {
    watchHash();
});